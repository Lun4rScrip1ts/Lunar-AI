@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Nebula AI - Lunar Installer

set "APPDATA_DIR=%LOCALAPPDATA%\Nebula-AI-Lunar\build-tools"
set "NODE_DIR=%APPDATA_DIR%\node-v22.14.0-win-x64"
set "NODE_ZIP=%APPDATA_DIR%\node-v22.14.0-win-x64.zip"
set "NODE_URL=https://nodejs.org/dist/v22.14.0/node-v22.14.0-win-x64.zip"

 echo.
echo  Nebula AI - Lunar 0.7.5 - Setup
echo  =================================
echo This setup downloads a temporary Node.js runtime, builds Nebula,
echo and opens the Windows installer. You do not need Node.js installed.
echo.

if not exist package.json (
  echo ERROR: package.json was not found. Extract the ZIP fully and run this file from its folder.
  pause
  exit /b 1
)

if not exist "%NODE_DIR%\node.exe" (
  echo [1/4] Downloading temporary Node.js runtime...
  if not exist "%APPDATA_DIR%" mkdir "%APPDATA_DIR%" 2>nul
  if not exist "%APPDATA_DIR%" (
    echo ERROR: Could not create the temporary build folder:
    echo %APPDATA_DIR%
    pause
    exit /b 1
  )
  curl.exe -fL "%NODE_URL%" -o "%NODE_ZIP%"
  if errorlevel 1 goto failed
  echo Extracting Node.js...
  tar.exe -xf "%NODE_ZIP%" -C "%APPDATA_DIR%"
  if errorlevel 1 goto failed
  del "%NODE_ZIP%" >nul 2>&1
)

set "PATH=%NODE_DIR%;%NODE_DIR%\node_modules\npm\bin;%PATH%"
if not exist "%NODE_DIR%\node.exe" (
  echo ERROR: Temporary Node.js runtime was not extracted correctly.
  goto failed
)

 echo [2/4] Installing project packages...
call "%NODE_DIR%\npm.cmd" install
if errorlevel 1 goto failed

 echo [3/4] Building the Windows installer...
call "%NODE_DIR%\npm.cmd" run dist
if errorlevel 1 goto failed

 echo [4/4] Locating the generated installer...
set "SETUP="
for /f "delims=" %%F in ('dir /b /a-d /o-d "release\Nebula-AI-Lunar-Setup-*.exe" 2^>nul') do (
  if not defined SETUP set "SETUP=%CD%\release\%%F"
)
if not defined SETUP (
  echo ERROR: Electron Builder completed but no Nebula installer EXE was found.
  echo Checked: %CD%\release\Nebula-AI-Lunar-Setup-*.exe
  echo Files currently in the release folder:
  if exist release dir /b release
  goto failed
)

echo Found installer:
echo %SETUP%
echo Opening the Windows installer...
start "Nebula AI - Lunar Setup" "%SETUP%"
echo.
echo The installer has been launched. Complete the setup wizard.
echo Nebula AI - Lunar should then appear in the Start Menu and on your desktop.
echo You can close this window.
pause
exit /b 0

:failed
echo.
echo SETUP DID NOT FINISH.
echo Please send a screenshot of the error above.
pause
exit /b 1

const { app, BrowserWindow, ipcMain, globalShortcut, screen, desktopCapturer, Tray, Menu, nativeImage, shell, safeStorage, clipboard, dialog } = require('electron')
const path = require('node:path')
const fs = require('node:fs')
const http = require('node:http')
const crypto = require('node:crypto')
const { spawn } = require('node:child_process')
const { jwtVerify, createRemoteJWKSet } = require('jose')

const APP_NAME = 'Nebula AI - Lunar'
const ISSUER = 'https://auth.openai.com'
const TOKEN_URL = 'https://auth.openai.com/api/accounts/oauth/token'
const AUTH_URL = 'https://auth.openai.com/api/accounts/authorize'
const RESOURCE = 'https://api.openai.com/v1'
const JWKS = createRemoteJWKSet(new URL('https://auth.openai.com/.well-known/jwks.json'))

let mainWindow
let selectionWindow
let answerHighlightWindow
let answerToastWindows = []
let answerToastFollowTimer = null
let tray
let authServer
let pendingCapture = null
let hostId
let credentials = null
let lastModel = null

const userDir = app.getPath('userData')
const authPath = path.join(userDir, 'connection.dat')
const apiKeyPath = path.join(userDir, 'image-api-key.dat')
const hostPath = path.join(userDir, 'host-id.txt')
const historyPath = path.join(userDir, 'history.json')
const conversationPath = path.join(userDir, 'conversation-memory.json')
const privacyPath = path.join(userDir, 'screen-privacy.json')
const blurPath = path.join(userDir, 'blur-setting.json')
const captureHotkeyPath = path.join(userDir, 'capture-hotkey.json')
let captureHotkey = 'Alt+Shift+A'
let captureHotkeyEnabled = true
let blurAmount = 0
let screenPrivacyEnabled = false

function readHostId() {
  try {
    const saved = fs.readFileSync(hostPath, 'utf8').trim()
    if (saved) return saved
  } catch {}

  const id = `urn:uuid:${crypto.randomUUID()}`
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(hostPath, id, 'utf8')
  return id
}

function loadCredentials() {
  try {
    if (!safeStorage.isEncryptionAvailable()) return null
    const encrypted = fs.readFileSync(authPath)
    return JSON.parse(safeStorage.decryptString(encrypted))
  } catch {
    return null
  }
}

function saveCredentials(value) {
  if (!safeStorage.isEncryptionAvailable()) {
    throw new Error('Windows credential encryption is unavailable. Restart Windows or check your user session.')
  }

  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(authPath, safeStorage.encryptString(JSON.stringify(value)))
  credentials = value
}

function clearCredentials() {
  credentials = null
  try {
    fs.unlinkSync(authPath)
  } catch {}
}

function loadScreenPrivacy() {
  try {
    const data = JSON.parse(fs.readFileSync(privacyPath, 'utf8'))
    screenPrivacyEnabled = Boolean(data.enabled)
  } catch {
    screenPrivacyEnabled = false
  }
}

function applyScreenPrivacy(enabled) {
  screenPrivacyEnabled = Boolean(enabled)
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.setContentProtection(screenPrivacyEnabled)
  }
  if (answerHighlightWindow && !answerHighlightWindow.isDestroyed()) {
    answerHighlightWindow.setContentProtection(screenPrivacyEnabled)
  }
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(privacyPath, JSON.stringify({ enabled: screenPrivacyEnabled }, null, 2), 'utf8')
  return { enabled: screenPrivacyEnabled }
}

function createMainWindow() {
  const display = screen.getPrimaryDisplay()
  const width = 850

  mainWindow = new BrowserWindow({
    title: '',
    width,
    height: 88,
    x: Math.round(display.workArea.x + (display.workArea.width - width) / 2),
    y: display.workArea.y + 20,
    show: false,
    frame: false,
    transparent: true,
    backgroundColor: '#00000000',
    backgroundMaterial: process.platform === 'win32' && blurAmount > 0 ? 'acrylic' : 'none',
    resizable: true,
    minWidth: 560,
    minHeight: 88,
    minimizable: false,
    maximizable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    hasShadow: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  })

  mainWindow.on('page-title-updated', event => {
    event.preventDefault()
    if (!mainWindow.isDestroyed()) mainWindow.setTitle('')
  })

  mainWindow.setAlwaysOnTop(true, 'screen-saver')
  mainWindow.setContentProtection(screenPrivacyEnabled)

  let didShow = false
  const revealWindow = () => {
    if (didShow || !mainWindow || mainWindow.isDestroyed()) return
    didShow = true
    mainWindow.show()
    mainWindow.focus()
    mainWindow.setAlwaysOnTop(true, 'screen-saver')
  }

  mainWindow.once('ready-to-show', revealWindow)
  mainWindow.webContents.once('did-finish-load', revealWindow)
  setTimeout(revealWindow, 1800)

  mainWindow.webContents.on('did-fail-load', (_, code, description) => {
    console.error('Nebula AI - Lunar failed to load:', code, description)
  })

  mainWindow.webContents.on('render-process-gone', (_, details) => {
    console.error('Nebula AI - Lunar renderer stopped:', details.reason)
  })

  mainWindow.loadFile(path.join(__dirname, 'index.html'))
  mainWindow.setTitle('')

  mainWindow.on('closed', () => {
    mainWindow = null
  })

  mainWindow.on('blur', () => {
    setTimeout(() => {
      if (
        mainWindow &&
        !mainWindow.isDestroyed() &&
        !mainWindow.isFocused() &&
        !mainWindow.webContents.isDevToolsOpened()
      ) {
        mainWindow.webContents.send('overlay-blurred')
      }
    }, 250)
  })
}

function showMainWindow(focus = true) {
  if (!mainWindow) {
    createMainWindow()
    return
  }

  mainWindow.setAlwaysOnTop(true, 'screen-saver')
  mainWindow.show()

  if (focus) mainWindow.focus()

  if (!mainWindow.webContents.isLoading()) {
    mainWindow.webContents.send('overlay-opened')
  } else {
    mainWindow.webContents.once('did-finish-load', () => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('overlay-opened')
      }
    })
  }
}

function toggleMainWindow() {
  if (!mainWindow) {
    showMainWindow()
    return
  }

  if (mainWindow.isVisible()) {
    mainWindow.hide()
  } else {
    showMainWindow()
  }
}

function createTray() {
  const icon = nativeImage.createFromDataURL(
    'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAKElEQVQ4T2NkYGD4z0AEYBxVSFUBCjA0MDAw/GfABKQGBoYh0QwMDAwAAN8ABf1l4QwAAAAASUVORK5CYII='
  )

  tray = new Tray(icon)
  tray.setToolTip(APP_NAME)

  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Open Nebula AI - Lunar', click: () => showMainWindow() },
    { label: 'Capture screen area', click: () => startCapture() },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ]))

  tray.on('double-click', () => showMainWindow())
}

function randomBase64Url(size = 32) {
  return crypto.randomBytes(size).toString('base64url')
}

function sha256Base64Url(value) {
  return crypto.createHash('sha256').update(value).digest('base64url')
}

function parseScopes(value) {
  return String(value || '').split(/\s+/).filter(Boolean)
}

async function signIn() {
  if (authServer) {
    throw new Error('A sign-in window is already waiting. Finish it in your browser first.')
  }

  const state = randomBase64Url()
  const nonce = randomBase64Url()
  const verifier = randomBase64Url(48)
  const challenge = sha256Base64Url(verifier)
  const server = http.createServer()

  authServer = server

  try {
    await new Promise((resolve, reject) => {
      server.once('error', reject)
      server.listen(0, '127.0.0.1', resolve)
    })

    const port = server.address().port
    const redirectUri = `http://127.0.0.1:${port}/auth/callback`

    const callbackPromise = new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('Sign-in timed out. Please try again.'))
      }, 5 * 60 * 1000)

      server.on('request', (req, res) => {
        const url = new URL(req.url, redirectUri)

        if (url.pathname !== '/auth/callback') {
          res.writeHead(404).end('Not found')
          return
        }

        if (url.searchParams.get('state') !== state) {
          res.writeHead(400, { 'content-type': 'text/html; charset=utf-8' })
            .end('<h2>Sign-in state did not match.</h2>You can close this tab.')
          clearTimeout(timeout)
          reject(new Error('Sign-in validation failed. Please try again.'))
          return
        }

        const error = url.searchParams.get('error')

        if (error) {
          res.writeHead(400, { 'content-type': 'text/html; charset=utf-8' })
            .end('<h2>Sign-in was not completed.</h2>You can close this tab and return to Nebula AI - Lunar.')
          clearTimeout(timeout)
          reject(new Error(`ChatGPT sign-in was not completed: ${error}`))
          return
        }

        const code = url.searchParams.get('code')
        const clientId = url.searchParams.get('client_id') || credentials?.clientId

        if (!code || !clientId) {
          res.writeHead(400, { 'content-type': 'text/html; charset=utf-8' })
            .end('<h2>Missing sign-in information.</h2>You can close this tab and try again.')
          clearTimeout(timeout)
          reject(new Error('The sign-in callback did not include the required information.'))
          return
        }

        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
          .end('<!doctype html><html><body style="font:16px Segoe UI;background:#0b1020;color:#edf4ff;padding:40px"><h2>Nebula AI - Lunar connected</h2><p>You can close this browser tab and return to the app.</p></body></html>')

        clearTimeout(timeout)
        resolve({ code, clientId })
      })
    })

    const params = new URLSearchParams({
      client_id: credentials?.clientId || 'dynamic_agent_client',
      response_type: 'code',
      redirect_uri: redirectUri,
      scope: 'openid profile email offline_access resource.invoke chatgpt.tokens.use.direct',
      resource: RESOURCE,
      state,
      nonce,
      code_challenge: challenge,
      code_challenge_method: 'S256',
      ext_agent_host_id: hostId,
      ...(!credentials?.clientId ? { agent_name_hint: APP_NAME } : {})
    })

    await shell.openExternal(`${AUTH_URL}?${params.toString()}`)

    if (mainWindow) {
      mainWindow.webContents.send('status-message', 'Complete sign-in in your browser…')
    }

    const callback = await callbackPromise
    const body = new URLSearchParams({
      grant_type: 'authorization_code',
      client_id: callback.clientId,
      code: callback.code,
      code_verifier: verifier,
      redirect_uri: redirectUri,
      resource: RESOURCE
    })

    const tokenResponse = await fetch(TOKEN_URL, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body
    })

    const tokenData = await tokenResponse.json()

    if (!tokenResponse.ok) {
      throw new Error(tokenData.error_description || tokenData.error || 'Token exchange failed.')
    }

    if (!tokenData.id_token || !tokenData.access_token) {
      throw new Error('ChatGPT did not return the required credentials.')
    }

    const { payload } = await jwtVerify(tokenData.id_token, JWKS, {
      issuer: ISSUER,
      audience: callback.clientId
    })

    if (payload.nonce !== nonce) {
      throw new Error('The sign-in nonce did not match. Please try again.')
    }

    const next = {
      clientId: callback.clientId,
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token || credentials?.refreshToken || null,
      expiresAt: Date.now() + Number(tokenData.expires_in || 3600) * 1000,
      scope: parseScopes(tokenData.scope),
      account: {
        subject: payload.sub,
        email: payload.email || '',
        name: payload.name || 'Connected ChatGPT account'
      },
      idToken: tokenData.id_token
    }

    saveCredentials(next)
    return getStatus()
  } finally {
    await new Promise(resolve => {
      if (!authServer) return resolve()
      const serverToClose = authServer
      authServer = null
      serverToClose.close(() => resolve())
    })
  }
}

async function getAccessToken() {
  if (!credentials) {
    throw new Error('Connect your ChatGPT account first.')
  }

  if (credentials.expiresAt && Date.now() < credentials.expiresAt - 60000) {
    return credentials.accessToken
  }

  if (!credentials.refreshToken) {
    throw new Error('Your ChatGPT connection expired. Please reconnect your account.')
  }

  const body = new URLSearchParams({
    grant_type: 'refresh_token',
    client_id: credentials.clientId,
    refresh_token: credentials.refreshToken,
    resource: RESOURCE
  })

  const response = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body
  })

  const data = await response.json()

  if (!response.ok) {
    clearCredentials()
    throw new Error('Your ChatGPT connection needs to be renewed. Please connect again.')
  }

  credentials = {
    ...credentials,
    accessToken: data.access_token,
    refreshToken: data.refresh_token || credentials.refreshToken,
    expiresAt: Date.now() + Number(data.expires_in || 3600) * 1000,
    scope: parseScopes(data.scope || (credentials.scope || []).join(' ')),
    idToken: data.id_token || credentials.idToken
  }

  saveCredentials(credentials)
  return credentials.accessToken
}

function getStatus() {
  if (!credentials) {
    return { connected: false, sharing: false, account: null }
  }

  const scopes = credentials.scope || []
  return {
    connected: true,
    sharing: scopes.includes('chatgpt.tokens.use.direct'),
    account: credentials.account || null
  }
}


function loadImageApiKey() {
  try {
    if (!safeStorage.isEncryptionAvailable()) return ''
    return safeStorage.decryptString(fs.readFileSync(apiKeyPath)).trim()
  } catch {
    return ''
  }
}

function saveImageApiKey(value) {
  const key = String(value || '').trim()
  if (!safeStorage.isEncryptionAvailable()) {
    throw new Error('Windows credential encryption is unavailable. Restart Windows or check your user session.')
  }
  if (key && !key.startsWith('sk-')) throw new Error('That does not look like an OpenAI API key.')
  fs.mkdirSync(userDir, { recursive: true })
  if (key) fs.writeFileSync(apiKeyPath, safeStorage.encryptString(key))
  else {
    try { fs.unlinkSync(apiKeyPath) } catch {}
  }
  return { configured: Boolean(key) }
}

async function generateImageWithApiKey(prompt, imageData, onProgress) {
  const apiKey = loadImageApiKey()
  if (!apiKey) throw new Error('Your ChatGPT sign-in cannot generate images. Add an OpenAI API key in Settings → Image generation. API usage is billed separately from ChatGPT.')
  onProgress({ type: 'status', text: 'Creating your image…' })
  const body = {
    model: 'gpt-image-1',
    prompt: String(prompt || 'Create an image based on the supplied reference image.'),
    size: '1024x1024',
    quality: 'high'
  }
  if (imageData) {
    throw new Error('Image editing from a screenshot is not available in this API-key image mode yet. Try generating a new image from a text description.')
  }
  const response = await fetch('https://api.openai.com/v1/images/generations', {
    method: 'POST',
    headers: { authorization: `Bearer ${apiKey}`, 'content-type': 'application/json' },
    body: JSON.stringify(body)
  })
  const data = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(data.error?.message || `Image generation failed with status ${response.status}. Check your API key and API billing.`)
  const encoded = data.data?.[0]?.b64_json
  if (!encoded) throw new Error('The image API returned no image data. Please try again.')
  onProgress({ type: 'status', text: 'Finishing your image…' })
  return { answer: '', model: 'gpt-image-1', imageData: `data:image/png;base64,${encoded}`, generatedImage: true }
}

function isImageRequest(prompt) {
  return /\b(generate|create|draw|paint|illustrate|render|make|turn|convert)\b.{0,90}\b(image|picture|illustration|artwork|wallpaper|logo|icon|poster|thumbnail|graphic|visual)\b/i.test(String(prompt || '')) ||
    /\b(make|turn|convert)\s+(this|that|it|the\s+svg)\s+(into|as)\s+(an?\s+)?(image|picture|png|jpg|jpeg)\b/i.test(String(prompt || ''))
}

async function askAI({ prompt, imageData, attachments = [], generateImage = false, conversation = [] }, onProgress = () => {}) {
  const cleanPrompt = String(prompt || '').trim()
  const shouldGenerateImage = Boolean(generateImage) || isImageRequest(cleanPrompt)

  if (!cleanPrompt && !imageData && !attachments.length) {
    throw new Error('Type a question, upload a file, or capture part of your screen first.')
  }

  if (shouldGenerateImage) return generateImageWithApiKey(cleanPrompt, imageData, onProgress)

  if (!credentials) {
    throw new Error('Connect your ChatGPT account first.')
  }

  if (!getStatus().sharing) {
    throw new Error('ChatGPT plan usage is not enabled. Reconnect and approve the requested permission if available.')
  }

  const token = await getAccessToken()
  const modelsResponse = await fetch(`${RESOURCE}/models`, {
    headers: { authorization: `Bearer ${token}` }
  })
  const modelsData = await modelsResponse.json()

  if (!modelsResponse.ok) {
    throw new Error(modelsData.error?.message || 'Could not load available ChatGPT models.')
  }

  const models = (modelsData.models || []).filter(model => model.visibility === 'list' && model.slug)
  const model = models.find(item => /gpt/i.test(item.slug)) || models[0]

  if (!model) {
    throw new Error('No models were returned for this ChatGPT account. Check your connection and granted permissions.')
  }

  lastModel = model.slug

  const content = [{
    type: 'input_text',
    text: shouldGenerateImage
      ? `Create an actual finished image for this request. Do not return SVG, HTML, Markdown, or image-generation code. Use the image generation tool and return the generated image itself. User request: ${cleanPrompt}`
      : (cleanPrompt || 'Analyze this screenshot and explain how to solve the problem shown.')
  }]

  if (imageData) content.push({ type: 'input_image', image_url: imageData })
  for (const file of attachments) {
    if (!file || typeof file.data !== 'string' || !file.data.startsWith('data:')) continue
    if (String(file.type || '').startsWith('image/')) {
      content.push({ type: 'input_image', image_url: file.data })
    } else if (String(file.type || '') === 'application/pdf') {
      content.push({ type: 'input_file', filename: String(file.name || 'document.pdf'), file_data: file.data })
    } else if (typeof file.text === 'string' && file.text.length) {
      content[0].text += `\n\nAttached file: ${String(file.name || 'file')}\n---\n${file.text.slice(0, 90000)}\n---`
    }
  }

  const tools = shouldGenerateImage
    ? [{
        type: 'image_generation',
        model: 'gpt-image-2.5-sunburst',
        action: imageData ? 'auto' : 'generate',
        partial_images: 2
      }]
    : undefined

  const systemText = shouldGenerateImage
    ? 'You are an image creation assistant. For image requests, use the image_generation tool to produce a complete raster image. Never substitute SVG or code for the image unless the user explicitly asks for source code. Keep any accompanying text brief.'
    : (imageData ? "You are Nebula AI - Lunar, a precise visual question assistant. Carefully inspect the entire supplied cropped screenshot, including small text, equations, dropdowns, and every answer field. First identify what the question is asking and solve it. Present the solution in a polished, readable worked-example format similar to a good online math lesson. Start with a short sentence naming the problem and the goal. Then use a clear heading such as **Step-by-step Solution** and number each step. For each step, state the operation in plain language, show the transformed equation on its own line, and briefly explain why the step is valid. Keep equations aligned and readable using valid LaTeX or standard Unicode math symbols. Finish with a clearly labeled **Final Answer** or **Solution** section that makes the final result easy to spot. For inequalities, include interval/inequality notation and explain open/closed endpoints and graph direction when relevant. For other subjects, adapt this structure to the question instead of forcing irrelevant math formatting. Keep the final answer first when the answer-only setting is selected; when explanation is enabled, put the final answer before the worked explanation. For number or text boxes, state the exact value to enter. For dropdowns, state the exact option wording visible in the dropdown when it can be read; do not invent option labels that are not visible. If the dropdown options are closed or unreadable, give the concept or value the user should look for and clearly say the exact label cannot be confirmed. Explain the key reasoning briefly so the user can check the result. Never guess when the screenshot is unclear; identify what needs a clearer capture. If you can confidently identify a specific answer field or choice, append exactly one marker at the very end: [[NEBULA_HIGHLIGHT:x,y,w,h]]. Coordinates are integers from 0 to 1000 relative to the supplied cropped image, with x and y as the top-left and w and h as width and height. The box should surround the actual final answer/result or answer field the user should look at, not the whole question. Make the target box generous enough to include the complete answer and a small margin around it; do not make a tiny box around one character. For a worked math solution, highlight the final simplified result or final answer line. If there are several answer fields, highlight the first one that should be completed. Do not mention the marker. Use clear standard Markdown. Render mathematical notation with actual Unicode symbols or valid LaTeX, never malformed fragments such as /g. Use standard arithmetic, relation, root, exponent, subscript, fraction, Greek, logic, set, geometry, and scientific symbols when relevant. When the screenshot or request involves GMetrix/GMETRIX, Microsoft Office, or a productivity task, act as a patient, comprehensive, beginner-friendly application coach. Support the full task, not just Excel copying: Excel workbooks, formulas, functions, formatting, tables, charts, sorting, filtering, conditional formatting, data validation, named ranges, PivotTables, worksheets, page setup, printing, and workbook management; Word documents, text editing, styles, themes, page layout, margins, columns, headers/footers, page numbers, tables, images, shapes, references, citations, mail merge, review tools, and printing; PowerPoint presentations, slides, layouts, themes, masters, text, images, shapes, SmartArt, charts, tables, audio/video, transitions, animations, notes, presenter view, and slide shows. Also help with other Microsoft 365 apps and GMetrix tasks when identifiable, adapting to the actual application shown.\n\nFirst identify the application, the task goal, and any constraints visible in the screenshot or supplied instructions. Then give an actionable sequence the user can perform. For Excel worksheet and GMetrix tasks, use a precise numbered, click-by-click procedure in the style of Office training instructions. Each step must contain ONE action only. Use exact worksheet tab names, cell addresses, ranges, Ribbon tab names, group names, button names, drop-down arrows, and menu option labels when visible. Bold interface labels and cell references. Specify exact target cells/ranges and complete formulas when formulas are needed; explain what a formula does briefly. For Word, provide complete beginner-level navigation for every operation. State what text, paragraph, page, table, image, or object to select before changing it. Name the Ribbon tab, group, and command (for example, Home > Font or Layout > Page Setup) when that path is known. For dialogs, tell the user which tab or section to open, which setting to change, the exact value to enter, and whether to click OK, Apply, or another confirmation button. Explain selection methods when needed (drag over text, double-click a word, use Ctrl+A only when the whole document is intended). For styles, explain how to open the Styles gallery and choose the requested style; for page layout, explain the relevant margins, orientation, size, columns, or spacing controls; for headers/footers and page numbers, explain how to insert them, choose a location/design, and exit the header/footer area; for tables and pictures, explain how to insert/select them and then use the contextual Table Design, Table Layout, or Picture Format tabs when available. Never just say “format it” or “apply a style.” End by describing what the document should look like and how to check the change. For PowerPoint, provide complete beginner-level navigation for every operation. First identify the slide number and the exact object or placeholder to select; explain how to select it in the slide canvas or Selection Pane if objects overlap. Name the Ribbon tab, group, and command when known. For text, explain how to click the placeholder or text box, select the intended text, and use the correct Home controls. For images, shapes, charts, tables, and SmartArt, explain how to insert or select the object, then use the relevant contextual Format, Chart Design, Table Design, or SmartArt Design controls. For slide layouts and themes, explain where to open Home > Layout or Design and which visible option to choose. For transitions, identify the slide(s), open Transitions, choose the effect, and explain Effect Options, Duration, Apply to All, and preview only when relevant. For animations, identify the object, open Animations, choose the effect, then explain Animation Pane, Start, Duration, Delay, and reordering when the task requires them. For slide order, explain how to select thumbnails and drag to the exact position. For audio/video or slide shows, explain the playback or presentation controls and how to preview the result. Never just say “add an animation,” “change the design,” or “insert a picture.” End by describing what the finished slide or presentation should look like and how to verify it. For charts, tables, diagrams, and other visual objects, explain how to select, edit, format, and verify them.\n\nCRITICAL: Never give a vague shortcut such as “use AutoFill,” “format the cells,” “apply a style,” “insert a chart,” or “use the ribbon” without explaining exactly how. Assume the user is a beginner who does not know where commands are. Expand every named tool or feature into the actual navigation and interaction steps. For Excel AutoFill specifically, explain the fill handle: click the starting cell (or select the complete seed range when it contains a pattern), move to the tiny square at the bottom-right corner of the selection until the pointer becomes a thin black plus, then drag across/down to the exact destination cell and release. State which source cell/range to select and the exact destination range. If the task is to repeat one value across cells, explain entering the value in the first cell, selecting the full destination range, and using Home > Editing > Fill > Right/Down when that path is available, or dragging the fill handle. If the task is to continue a series (such as months or dates), explain that the seed range must contain enough starting values to establish the pattern, then use the fill handle to extend it. Do not assume whether Excel should copy or extend a series; use the visible data and task wording to choose, and mention the Auto Fill Options button only if relevant. For example, if the visible sheet confirms January, February, and March in B2:D2 and the task asks to continue through December, say to select B2:D2, drag the fill handle at the bottom-right of D2 across to M2, and check that the months continue in order. For a constant $10 value, say to enter 10 in B3, select or fill across B3:M3, and verify each cell contains 10; do not add currency formatting unless the task requests it. Adapt these examples to the actual screenshot—never invent starting values or ranges.\n\nFor every Excel task, include: (1) where to start, (2) the exact cell/range to click or select, (3) the Ribbon tab and group to open, (4) the exact button/menu item to choose, (5) what to drag/type/select, (6) where to stop, and (7) how to confirm the result. If a command has multiple ways to do it, give the simplest reliable method first and optionally one alternative. Do not skip mouse interactions such as opening a dropdown, dragging a handle, releasing the mouse, or confirming a dialog. Break compound actions into separate numbered steps, one action per step. Avoid unexplained jargon; briefly define terms like fill handle, range, formula bar, and active cell when first needed.\n\nFor Word and PowerPoint tasks, use the same strict one-action-per-numbered-step format as Excel: include where to start, what to select, the exact tab/group/button/menu item, what to enter or choose, any dialog confirmation, and how to verify the outcome. If the task has several objects or slides, handle them in the correct order and identify each one. Explain unfamiliar interface terms briefly. Do not skip the click that opens a menu, gallery, pane, or dialog. Do not limit assistance to the example task or to copying/pasting. Help with any operation the task asks for, including creating, editing, formatting, organizing, analyzing, reviewing, presenting, saving, exporting, and printing. Explain prerequisite steps and navigation where needed. If a task has multiple parts, order all steps from start to finish and do not skip dependencies. End with a concise verification step describing the expected result. If the screenshot shows only part of the task, give the next useful step and ask for another screenshot after the user completes it.\n\nUse labels and options visible in the screenshot whenever possible. Never invent a worksheet, cell, button, Ribbon group, menu item, or dialog setting. If something is unclear or hidden, say exactly what needs to be shown and ask for a clearer or wider screenshot. Office versions and layouts can differ, so mention alternatives only when they are genuinely plausible. Keep steps concise, specific, and easy to follow; avoid vague instructions like \u201cformat it appropriately.\u201d Explain unfamiliar terms briefly when useful. Do not claim to control Word, PowerPoint, Excel, GMetrix, or other apps directly; the user performs the actions." : 'You are Nebula AI - Lunar, a capable and conversational desktop assistant. Maintain continuity across messages. Treat follow-up prompts such as “explain that”, “continue”, “solve this”, and “what about the next one?” as referring to earlier conversation when appropriate. Do not ask the user to repeat context already present. Give direct answers and explain key reasoning. For school-style problems, solve the actual problem and explain the steps. For troubleshooting, identify likely causes and give practical steps. For screenshots, describe only what is visible. Use clear standard Markdown. Render mathematical notation with actual Unicode symbols or valid LaTeX, never malformed fragments such as /g. Use standard arithmetic, relation, root, exponent, subscript, fraction, Greek, logic, set, geometry, and scientific symbols when relevant. When the screenshot or request shows Microsoft Word, PowerPoint, Excel, or a GMetrix/GMETRIX practice task, act as a patient Office skills coach. Do not merely state the final result. Give an actionable sequence the user can follow in the application. Start by naming the goal in one sentence. Then provide numbered steps, one clear action per step, using the exact visible Ribbon tab, group, button, menu, dialog, cell, or worksheet names whenever readable. Tell the user where to click, what value/text/formula to enter, and what setting to choose. For Excel, give exact cell references and formulas, explain the range to select, and mention fill/copy steps only when needed. For Word, specify the tab and formatting/layout commands, selection scope, and relevant dialog options. For PowerPoint, specify the slide, object, selection, arrangement, design, transition, or animation controls involved. After the steps, describe what the finished result should look like and how to verify it. For Excel, never say only “use AutoFill” or “drag to fill”: tell the user exactly which cell or seed range to select, where the small fill handle is (bottom-right corner of the selection), how to drag it, which destination cell to stop at, and what values should appear. For a repeated value, explain how to enter it in the first cell and fill the destination range; for a series such as months, explain how the starting values establish the pattern before extending it. Include ribbon navigation such as **Home** > **Editing** > **Fill** when using that route, but do not invent a ribbon location if it is not confirmed for the user’s Excel version. Do not assume example cells or values that are not visible. If the screenshot shows only part of the task, state the next safe step and ask for a new screenshot after the user completes it. Never invent a button, tab, cell, or option that is not visible or confidently known; mention when labels may differ by Office version. Keep each instruction concise and beginner-friendly, and guide one task at a time. Do not claim to control Word, PowerPoint, Excel, or GMetrix directly; the user performs the actions.')

  const conversationInput = (Array.isArray(conversation) ? conversation : [])
    .filter(item => item && ['user', 'assistant'].includes(item.role) && typeof item.text === 'string' && item.text.trim())
    .slice(-16)
    .map(item => ({ role: item.role, content: [{ type: item.role === 'assistant' ? 'output_text' : 'input_text', text: item.text.slice(0, 12000) }] }))

  conversationInput.push({ role: 'user', content })

  const requestBody = {
    model: model.slug,
    input: [
      { role: 'system', content: [{ type: 'input_text', text: systemText }] },
      ...conversationInput
    ],
    store: false,
    stream: true
  }

  if (tools) {
    requestBody.tools = tools
    requestBody.tool_choice = 'required'
  }

  if (shouldGenerateImage) onProgress({ type: 'status', text: 'Creating your image…' })

  const response = await fetch(`${RESOURCE}/responses`, {
    method: 'POST',
    headers: {
      authorization: `Bearer ${token}`,
      'content-type': 'application/json'
    },
    body: JSON.stringify(requestBody)
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}))
    const message = errorData.error?.message || `AI request failed with status ${response.status}.`
    if (shouldGenerateImage && [400, 403, 404, 422].includes(response.status)) {
      throw new Error(`Image generation is not available through this ChatGPT connection, or the image tool was rejected. Details: ${message}`)
    }
    throw new Error(message)
  }

  if (!response.body) throw new Error('The AI response stream was empty.')

  let answer = ''
  let generatedImage = null
  let buffer = ''

  const handleSseLine = line => {
    if (!line.startsWith('data: ')) return
    const value = line.slice(6).trim()
    if (!value || value === '[DONE]') return

    let event
    try { event = JSON.parse(value) } catch { return }

    if (event.type === 'response.output_text.delta') answer += event.delta || ''

    if (event.type === 'response.image_generation_call.in_progress' || event.type === 'response.image_generation_call.generating') {
      onProgress({ type: 'status', text: 'Rendering the image…' })
    }

    if (event.type === 'response.image_generation_call.partial_image' && event.partial_image_b64) {
      onProgress({ type: 'partial-image', dataUrl: `data:image/png;base64,${event.partial_image_b64}` })
    }

    if (event.type === 'response.completed') {
      const output = event.response?.output || []
      const imageCall = output.find(item => item.type === 'image_generation_call' && item.result)
      if (imageCall?.result) generatedImage = `data:image/png;base64,${imageCall.result}`
      if (!answer.trim() && event.response?.output_text) answer = event.response.output_text
    }

    if (event.type === 'response.failed' || event.type === 'error') {
      throw new Error(event.response?.error?.message || event.error?.message || 'The AI response failed.')
    }
  }

  for await (const chunk of response.body) {
    buffer += Buffer.from(chunk).toString('utf8')
    const lines = buffer.split(/\r?\n/)
    buffer = lines.pop() || ''
    for (const line of lines) handleSseLine(line)
  }
  if (buffer.trim()) handleSseLine(buffer.trim())

  if (shouldGenerateImage && !generatedImage) {
    if (!answer.trim()) {
      throw new Error('The connection finished without returning an image. Image generation may not be enabled for this ChatGPT connection.')
    }
    throw new Error(`The AI returned text instead of a generated image. Try again, or check whether image generation is supported by this connection. Response: ${answer.slice(0, 300)}`)
  }

  if (!answer.trim() && !generatedImage) throw new Error('The AI returned no text or image. Try again.')

  let highlightBox = null
  const marker = answer.match(/\[\[NEBULA_HIGHLIGHT:(\d{1,4}),(\d{1,4}),(\d{1,4}),(\d{1,4})\]\]/)
  if (marker) {
    const values = marker.slice(1).map(Number)
    if (values.every(value => Number.isFinite(value) && value >= 0 && value <= 1000) && values[2] > 0 && values[3] > 0) {
      highlightBox = { x: values[0], y: values[1], width: values[2], height: values[3] }
      answer = answer.replace(marker[0], '').trim()
    }
  }
  return { answer: answer.trim(), model: model.slug, imageData: generatedImage, generatedImage: Boolean(generatedImage), highlightBox }
}

async function startCapture() {
  if (selectionWindow && !selectionWindow.isDestroyed()) {
    selectionWindow.focus()
    return
  }

  const display = screen.getPrimaryDisplay()
  const { width, height, x, y } = display.bounds

  try {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.hide()
    await new Promise(resolve => setTimeout(resolve, 140))

    const sources = await desktopCapturer.getSources({
      types: ['screen'],
      thumbnailSize: {
        width: Math.max(1280, width),
        height: Math.max(720, height)
      }
    })

    const source = sources.find(item => item.display_id === String(display.id)) || sources[0]
    if (!source) throw new Error('Could not capture the screen.')

    pendingCapture = { dataUrl: source.thumbnail.toDataURL(), screenBounds: { x, y, width, height } }

    selectionWindow = new BrowserWindow({
      x, y, width, height,
      show: false,
      frame: false,
      transparent: false,
      backgroundColor: '#070b14',
      resizable: false,
      movable: false,
      skipTaskbar: true,
      alwaysOnTop: true,
      fullscreen: true,
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true
      }
    })

    selectionWindow.setAlwaysOnTop(true, 'screen-saver')
    selectionWindow.setContentProtection(screenPrivacyEnabled)
    selectionWindow.webContents.on('did-fail-load', (_, code, description) => {
      console.error('Screen selection failed to load:', code, description)
      if (selectionWindow && !selectionWindow.isDestroyed()) selectionWindow.close()
      showMainWindow()
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('status-message', 'Screen capture could not open. The capture window was closed safely.')
      }
    })

    selectionWindow.loadFile(path.join(__dirname, 'selection.html')).catch(error => {
      console.error('Could not load screen selection:', error)
      closeSelection()
      showMainWindow()
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('status-message', 'Screen capture files are missing or could not be loaded.')
      }
    })

    selectionWindow.once('ready-to-show', () => {
      if (!selectionWindow || selectionWindow.isDestroyed()) return
      selectionWindow.show()
      selectionWindow.webContents.send('capture-image', pendingCapture)
    })

    selectionWindow.on('closed', () => {
      selectionWindow = null
      pendingCapture = null
      if (mainWindow && !mainWindow.isDestroyed() && !mainWindow.isVisible()) showMainWindow()
    })
  } catch (error) {
    console.error('Screen capture failed:', error)
    showMainWindow()
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('status-message', error.message || 'Screen capture failed.')
    }
  }
}

function showAnswerHighlight(bounds) {
  if (!bounds || ![bounds.x, bounds.y, bounds.width, bounds.height].every(Number.isFinite)) return false
  if (answerHighlightWindow && !answerHighlightWindow.isDestroyed()) answerHighlightWindow.close()
  const x = Math.round(bounds.x)
  const y = Math.round(bounds.y)
  const width = Math.max(18, Math.round(bounds.width))
  const height = Math.max(18, Math.round(bounds.height))
  const current = new BrowserWindow({
    x, y, width, height, frame: false, transparent: true, backgroundColor: '#00000000',
    resizable: false, movable: false, focusable: false, skipTaskbar: true,
    alwaysOnTop: true, hasShadow: false, show: false,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true }
  })
  answerHighlightWindow = current
  current.setAlwaysOnTop(true, 'screen-saver')
  current.setContentProtection(screenPrivacyEnabled)
  current.setIgnoreMouseEvents(true, { forward: true })
  current.loadFile(path.join(__dirname, 'answer-highlight.html'))
  current.once('ready-to-show', () => {
    if (!current.isDestroyed()) { current.showInactive(); current.setAlwaysOnTop(true, 'screen-saver') }
  })
  current.webContents.once('did-finish-load', () => {
    if (!current.isDestroyed()) current.webContents.send('animate-highlight')
  })
  setTimeout(() => { if (!current.isDestroyed()) current.close() }, 3000)
  current.on('closed', () => { if (answerHighlightWindow === current) answerHighlightWindow = null })
  return true
}


function relayoutAnswerToasts() {
  answerToastWindows = answerToastWindows.filter(item => item.window && !item.window.isDestroyed())
  if (!app.isReady() || answerToastWindows.length === 0) return
  const cursor = screen.getCursorScreenPoint()
  const display = screen.getDisplayNearestPoint(cursor)
  const work = display.workArea
  let y = Math.min(cursor.y + 22, work.y + work.height - 90)
  for (const item of answerToastWindows) {
    const targetX = Math.max(work.x + 10, Math.min(cursor.x + 16, work.x + work.width - item.width - 10))
    const targetY = Math.max(work.y + 10, Math.min(y, work.y + work.height - item.height - 10))
    if (item.x == null) { item.x = targetX; item.y = targetY }
    else { item.x += (targetX - item.x) * 0.24; item.y += (targetY - item.y) * 0.24 }
    item.window.setBounds({ x: Math.round(item.x), y: Math.round(item.y), width: item.width, height: item.height }, false)
    y = targetY + item.height + 8
  }
}

function showAnswerToast(answer, durationSeconds = 5) {
  const text = String(answer || '').trim()
  if (!text) return false
  const width = 310
  const height = 82
  const toastWindow = new BrowserWindow({
    width, height, show: false, frame: false, transparent: true, resizable: false,
    movable: false, focusable: false, skipTaskbar: true, alwaysOnTop: true, hasShadow: false,
    backgroundColor: '#00000000',
    webPreferences: { preload: path.join(__dirname, 'answer-toast-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  })
  toastWindow.setAlwaysOnTop(true, 'screen-saver')
  toastWindow.setContentProtection(screenPrivacyEnabled)
  toastWindow.setIgnoreMouseEvents(true)
  const item = { window: toastWindow, width, height, timer: null, x: null, y: null }
  answerToastWindows.push(item)
  toastWindow.loadFile(path.join(__dirname, 'answer-toast.html'))
  toastWindow.once('ready-to-show', () => {
    if (toastWindow.isDestroyed()) return
    toastWindow.showInactive()
    toastWindow.webContents.send('answer-toast-content', text)
    relayoutAnswerToasts()
  })
  item.timer = setTimeout(() => {
    if (!toastWindow.isDestroyed()) {
      toastWindow.webContents.executeJavaScript("document.querySelector('.card')?.classList.add('leaving')").catch(() => {})
      setTimeout(() => { if (!toastWindow.isDestroyed()) toastWindow.close() }, 230)
    }
  }, Math.max(1, Math.min(60, Number(durationSeconds) || 5)) * 1000)
  toastWindow.on('closed', () => {
    clearTimeout(item.timer)
    answerToastWindows = answerToastWindows.filter(entry => entry !== item)
    relayoutAnswerToasts()
  })
  return true
}

function closeSelection() {
  if (selectionWindow && !selectionWindow.isDestroyed()) selectionWindow.close()
  selectionWindow = null
  pendingCapture = null
}

function readHistory() {
  try {
    return JSON.parse(fs.readFileSync(historyPath, 'utf8'))
  } catch {
    return []
  }
}

function writeHistory(items) {
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(historyPath, JSON.stringify(items.slice(-50), null, 2), 'utf8')
}

function isSingleKeyAccelerator(value) {
  return /^[A-Za-z0-9]$/.test(String(value || '').trim())
}

function registerCaptureHotkey(accelerator) {
  if (captureHotkey && !isSingleKeyAccelerator(captureHotkey)) globalShortcut.unregister(captureHotkey)
  const next = String(accelerator || '').trim()
  if (!next) throw new Error('Choose a key first.')
  if (captureHotkeyEnabled && !isSingleKeyAccelerator(next) && !globalShortcut.register(next, () => {
    if (mainWindow && !mainWindow.isDestroyed() && mainWindow.isFocused()) {
      mainWindow.webContents.executeJavaScript("(() => { const e = document.activeElement; return !!(e && (e.matches('input, textarea, select') || e.isContentEditable)); })()")
        .then(isTyping => { if (!isTyping) startCapture() })
        .catch(() => {})
      return
    }
    startCapture()
  })) {
    if (captureHotkeyEnabled && captureHotkey && !isSingleKeyAccelerator(captureHotkey)) {
      globalShortcut.register(captureHotkey, startCapture)
    }
    throw new Error(`The screen capture key ${next} is unavailable. Choose another key.`)
  }
  captureHotkey = next
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(captureHotkeyPath, JSON.stringify({ accelerator: next, enabled: captureHotkeyEnabled }), 'utf8')
  return { accelerator: next, enabled: captureHotkeyEnabled }
}

function setCaptureHotkeyEnabled(enabled) {
  captureHotkeyEnabled = Boolean(enabled)
  if (captureHotkey && !isSingleKeyAccelerator(captureHotkey)) globalShortcut.unregister(captureHotkey)
  if (captureHotkeyEnabled && captureHotkey && !isSingleKeyAccelerator(captureHotkey) && !globalShortcut.register(captureHotkey, () => {
    if (mainWindow && !mainWindow.isDestroyed() && mainWindow.isFocused()) {
      mainWindow.webContents.executeJavaScript("(() => { const e = document.activeElement; return !!(e && (e.matches('input, textarea, select') || e.isContentEditable)); })()")
        .then(isTyping => { if (!isTyping) startCapture() })
        .catch(() => {})
      return
    }
    startCapture()
  })) {
    captureHotkeyEnabled = false
    throw new Error(`Could not activate ${captureHotkey}. That key is already in use.`)
  }
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(captureHotkeyPath, JSON.stringify({ accelerator: captureHotkey, enabled: captureHotkeyEnabled }), 'utf8')
  return { accelerator: captureHotkey, enabled: captureHotkeyEnabled }
}

app.whenReady().then(() => {
  if (!answerToastFollowTimer) {
    answerToastFollowTimer = setInterval(relayoutAnswerToasts, 16)
  }
  hostId = readHostId()
  credentials = loadCredentials()
  loadScreenPrivacy()
  try { const savedHotkey = JSON.parse(fs.readFileSync(captureHotkeyPath, 'utf8')); captureHotkey = savedHotkey.accelerator || 'Alt+Shift+A'; captureHotkeyEnabled = savedHotkey.enabled !== false } catch {}
  try { blurAmount = Math.max(0, Math.min(60, Number(JSON.parse(fs.readFileSync(blurPath, 'utf8')).value) || 0)) } catch {}
  createMainWindow()
  createTray()
  globalShortcut.register('Alt+Space', toggleMainWindow)
  if (captureHotkeyEnabled && !isSingleKeyAccelerator(captureHotkey)) registerCaptureHotkey(captureHotkey)
}).catch(error => {
  console.error('Nebula AI - Lunar failed to start:', error)
  dialog.showErrorBox('Nebula AI - Lunar could not start', String(error && error.stack || error))
  app.quit()
})

app.on('activate', () => showMainWindow())
app.on('will-quit', () => { globalShortcut.unregisterAll() })
app.on('window-all-closed', event => event.preventDefault())

ipcMain.handle('copy-text', (_, value) => { clipboard.writeText(String(value ?? '')); return true })
ipcMain.handle('open-external', async (_, value) => {
  try {
    const url = new URL(String(value))
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return false
    await shell.openExternal(url.href)
    return true
  } catch {
    return false
  }
})
ipcMain.handle('get-status', () => getStatus())
ipcMain.handle('get-image-api-key-status', () => ({ configured: Boolean(loadImageApiKey()) }))
ipcMain.handle('save-image-api-key', (_, value) => saveImageApiKey(value))
ipcMain.handle('set-window-dragging', (_, dragging) => { mainWindowDragging = Boolean(dragging); return true })
ipcMain.handle('get-window-bounds', () => {
  if (!mainWindow || mainWindow.isDestroyed()) return null
  return mainWindow.getBounds()
})
ipcMain.on('move-window', (_, position) => {
  if (!mainWindow || mainWindow.isDestroyed() || !position) return
  const x = Number(position.x)
  const y = Number(position.y)
  if (!Number.isFinite(x) || !Number.isFinite(y)) return
  const display = screen.getDisplayMatching(mainWindow.getBounds())
  const bounds = mainWindow.getBounds()
  const maxX = display.workArea.x + display.workArea.width - bounds.width
  const maxY = display.workArea.y + display.workArea.height - 40
  const nextX = Math.round(Math.max(display.workArea.x - bounds.width + 80, Math.min(x, maxX)))
  const nextY = Math.round(Math.max(display.workArea.y, Math.min(y, maxY)))
  mainWindow.setBounds({ x: nextX, y: nextY, width: bounds.width, height: bounds.height }, false)
})
ipcMain.handle('get-privacy', () => ({ enabled: screenPrivacyEnabled }))
ipcMain.handle('get-blur', () => ({ value: blurAmount }))
ipcMain.handle('set-blur', (_, value) => {
  blurAmount = Math.max(0, Math.min(60, Number(value) || 0))
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(blurPath, JSON.stringify({ value: blurAmount }), 'utf8')
  if (mainWindow && !mainWindow.isDestroyed()) {
    if (process.platform === 'win32' && typeof mainWindow.setBackgroundMaterial === 'function') {
      mainWindow.setBackgroundMaterial(blurAmount === 0 ? 'none' : 'acrylic')
    }
    mainWindow.webContents.send('blur-updated', blurAmount)
  }
  return { value: blurAmount }
})
ipcMain.handle('set-privacy', (_, enabled) => applyScreenPrivacy(enabled))
ipcMain.handle('resize-window', (_, size) => {
  if (!mainWindow || mainWindow.isDestroyed() || !size || mainWindowDragging) return false
  const width = Math.max(560, Math.min(1600, Math.round(Number(size.width) || 900)))
  const height = Math.max(360, Math.min(1200, Math.round(Number(size.height) || 680)))
  const [currentWidth, currentHeight] = mainWindow.getSize()
  if (width === currentWidth && height === currentHeight) return true
  mainWindow.setSize(width, height, true)
  return true
})

ipcMain.handle('signin', async () => {
  const status = await signIn()
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('status-updated', status)
  }
  return status
})

ipcMain.handle('signout', () => {
  clearCredentials()
  const status = getStatus()
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('status-updated', status)
  }
  return status
})

ipcMain.handle('load-conversation-memory', () => {
  try {
    const data = JSON.parse(fs.readFileSync(conversationPath, 'utf8'))
    return Array.isArray(data) ? data.slice(-40) : []
  } catch {
    return []
  }
})

ipcMain.handle('save-conversation-memory', (_, messages) => {
  const safeMessages = (Array.isArray(messages) ? messages : [])
    .filter(item => item && ['user', 'assistant'].includes(item.role) && typeof item.text === 'string')
    .slice(-40)
    .map(item => ({ role: item.role, text: item.text.slice(0, 12000), time: Number(item.time) || Date.now() }))
  fs.mkdirSync(userDir, { recursive: true })
  fs.writeFileSync(conversationPath, JSON.stringify(safeMessages), 'utf8')
  return { saved: true }
})

ipcMain.handle('clear-conversation-memory', () => {
  try { fs.unlinkSync(conversationPath) } catch {}
  return { cleared: true }
})

ipcMain.handle('ask', async (event, payload) => {
  const result = await askAI(payload, progress => {
    if (!event.sender.isDestroyed()) event.sender.send('generation-progress', progress)
  })
  const history = readHistory()
  history.push({
    id: crypto.randomUUID(),
    time: new Date().toISOString(),
    prompt: String(payload.prompt || ''),
    answer: result.answer || (result.generatedImage ? 'Generated image' : ''),
    model: result.model,
    hasImage: Boolean(payload.imageData),
    generatedImage: Boolean(result.generatedImage)
  })
  writeHistory(history)
  return result
})

ipcMain.handle('save-image', async (_, dataUrl) => {
  if (typeof dataUrl !== 'string' || !/^data:image\/png;base64,/i.test(dataUrl)) {
    throw new Error('This image cannot be saved because its format is not supported.')
  }
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'Save generated image',
    defaultPath: 'Nebula-AI-Lunar-Image.png',
    filters: [{ name: 'PNG image', extensions: ['png'] }]
  })
  if (result.canceled || !result.filePath) return { canceled: true }
  const match = dataUrl.match(/^data:image\/png;base64,(.+)$/i)
  fs.writeFileSync(result.filePath, Buffer.from(match[1], 'base64'))
  return { canceled: false, filePath: result.filePath }
})

ipcMain.handle('capture', () => startCapture())
ipcMain.handle('capture-hotkey-pressed', () => {
  if (!captureHotkeyEnabled || !isSingleKeyAccelerator(captureHotkey)) return false
  return startCapture()
})
ipcMain.handle('show-answer-highlight', (_, bounds) => showAnswerHighlight(bounds))
ipcMain.handle('show-answer-toast', (_, payload) => showAnswerToast(payload?.answer, payload?.duration))
ipcMain.on('answer-toast-size', (event, size) => {
  const item = answerToastWindows.find(entry => entry.window && !entry.window.isDestroyed() && entry.window.webContents === event.sender)
  if (!item) return
  const display = screen.getDisplayNearestPoint(screen.getCursorScreenPoint())
  const maxHeight = Math.max(120, Math.floor(display.workArea.height * 0.65))
  const nextHeight = Math.max(72, Math.min(maxHeight, Math.ceil(Number(size?.height) || item.height)))
  if (Math.abs(nextHeight - item.height) > 2) {
    item.height = nextHeight
    relayoutAnswerToasts()
  }
})

ipcMain.handle('get-capture-hotkey', () => ({ accelerator: captureHotkey }))
ipcMain.handle('set-capture-hotkey', (_, accelerator) => registerCaptureHotkey(accelerator))
ipcMain.handle('set-capture-hotkey-enabled', (_, enabled) => setCaptureHotkeyEnabled(enabled))
ipcMain.handle('capture-finished', (_, payload) => {
  closeSelection()
  showMainWindow()
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('image-captured', payload)
  }
  return true
})
ipcMain.handle('capture-cancel', () => {
  closeSelection()
  showMainWindow()
  return true
})
ipcMain.handle('get-history', () => readHistory())
ipcMain.handle('delete-history-item', (_, id) => {
  const items = readHistory().filter(item => item.id !== String(id))
  writeHistory(items)
  return items
})
ipcMain.handle('delete-all-history', () => {
  writeHistory([])
  return true
})
ipcMain.handle('open-usage', () => shell.openExternal('https://chatgpt.com/settings/usage'))
ipcMain.handle('set-expanded', (_, expanded) => {
  if (!mainWindow || mainWindow.isDestroyed()) return false
  const display = screen.getDisplayMatching(mainWindow.getBounds())
  const bounds = mainWindow.getBounds()
  let width = bounds.width
  let height = bounds.height
  if (expanded && height <= 100) {
    width = 900
    height = 620
  } else if (!expanded) {
    height = 88
  }
  const centerX = bounds.x + bounds.width / 2
  const x = Math.round(Math.max(display.workArea.x, Math.min(centerX - width / 2, display.workArea.x + display.workArea.width - width)))
  const y = Math.max(display.workArea.y + 12, Math.min(bounds.y, display.workArea.y + display.workArea.height - height))
  mainWindow.setBounds({ x, y, width, height }, true)
  mainWindow.setAlwaysOnTop(true, 'screen-saver')
  mainWindow.setContentProtection(screenPrivacyEnabled)
  return true
})
ipcMain.handle('hide-overlay', () => {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.hide()
  return true
})
ipcMain.handle('show-overlay', () => {
  showMainWindow()
  return true
})
ipcMain.handle('status', () => getStatus())

const $ = id => document.getElementById(id)
const promptInput = $('prompt')
const panel = $('panel')
const conversation = $('conversation')
const welcome = $('welcome')
const statusLine = $('statusLine')
const attachment = $('attachment')
const attachmentPreview = $('attachmentPreview')
const settingsView = $('settingsView')
const historyView = $('historyView')
let imageData = null
let captureBounds = null
let attachedFiles = []
let busy = false
let expanded = false
let activeLoading = null
let isScreenCaptureRequest = false
let showExplanation = false
let answerToastDuration = 5

function loadAnswerDisplaySettings() {
  try {
    showExplanation = localStorage.getItem('nebulaShowExplanation') === 'true'
    answerToastDuration = Math.max(1, Math.min(60, Number(localStorage.getItem('nebulaAnswerToastDuration')) || 5))
  } catch {}
  if ($('showExplanationToggle')) $('showExplanationToggle').checked = showExplanation
  if ($('answerToastDuration')) $('answerToastDuration').value = String(answerToastDuration)
}

function splitCaptureAnswer(raw) {
  const text = String(raw || '').trim()
  const answerMatch = text.match(/(?:^|\\n)\\s*(?:\\*\\*)?ANSWER(?:\\*\\*)?\\s*:?\\s*([\\s\\S]*?)(?=\\n\\s*(?:\\*\\*)?EXPLANATION(?:\\*\\*)?\\s*:?|$)/i)
  const explanationMatch = text.match(/(?:^|\\n)\\s*(?:\\*\\*)?EXPLANATION(?:\\*\\*)?\\s*:?\\s*([\\s\\S]*)$/i)
  if (answerMatch) return { answer: answerMatch[1].trim(), explanation: explanationMatch ? explanationMatch[1].trim() : '' }
  return { answer: text.split(/\\n\\s*\\n/)[0] || text, explanation: text.split(/\\n\\s*\\n/).slice(1).join('\\n\\n') }
}


function toast(message) {
  const el = $('toast')
  el.textContent = message
  el.hidden = false
  clearTimeout(toast.timer)
  toast.timer = setTimeout(() => { el.hidden = true }, 4200)
}

function setStatus(message) {
  statusLine.textContent = message
}

function showPanel() {
  expanded = true
  panel.classList.add('open')
  document.querySelector('.shell').classList.add('expanded')
  window.glassAI.setExpanded(true)
}

function hideViews() {
  settingsView.hidden = true
  historyView.hidden = true
  conversation.hidden = false
  $('attachment').hidden = !imageData && attachedFiles.length === 0
}

function normalizeAssistantText(value) {
  return String(value ?? '')
    .replace(/\\{1,2}([()[\]])/g, '$1')
    .replace(/\\\*\*/g, '**')
    .replace(/\\\*/g, '*')
    .replace(/\\`/g, '`')
    .replace(/\r\n?/g, '\n')
}

function appendInlineMarkdown(parent, rawText) {
  const text = normalizeAssistantText(rawText)
  const tokenPattern = /(`[^`\n]+`|\*\*[^*\n]+\*\*|__[^_\n]+__|(?<!\*)\*[^*\n]+\*(?!\*)|(?<!_)_[^_\n]+_(?!_)|\[[^\]]+\]\(https?:\/\/[^\s)]+\))/g
  let lastIndex = 0
  let match

  while ((match = tokenPattern.exec(text)) !== null) {
    if (match.index > lastIndex) parent.appendChild(document.createTextNode(text.slice(lastIndex, match.index)))
    const token = match[0]
    let node

    if (token.startsWith('`')) {
      node = document.createElement('code')
      node.textContent = token.slice(1, -1)
    } else if (token.startsWith('**') || token.startsWith('__')) {
      node = document.createElement('strong')
      node.textContent = token.slice(2, -2)
    } else if (token.startsWith('*') || token.startsWith('_')) {
      node = document.createElement('em')
      node.textContent = token.slice(1, -1)
    } else {
      const linkMatch = token.match(/^\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)$/)
      node = document.createElement('a')
      node.textContent = linkMatch[1]
      node.href = linkMatch[2]
      node.rel = 'noreferrer noopener'
      node.target = '_blank'
      node.addEventListener('click', event => {
        event.preventDefault()
        window.glassAI.openExternal(node.href)
      })
    }

    parent.appendChild(node)
    lastIndex = tokenPattern.lastIndex
  }

  if (lastIndex < text.length) parent.appendChild(document.createTextNode(text.slice(lastIndex)))
}

function renderAssistantMarkdown(container, rawText) {
  const text = normalizeAssistantText(rawText)
  const lines = text.split('\n')
  let index = 0

  while (index < lines.length) {
    const line = lines[index]
    if (!line.trim()) { index++; continue }

    if (/^\s*```/.test(line)) {
      const language = line.trim().slice(3).trim().split(/\s+/)[0] || 'code'
      const codeLines = []
      index++
      while (index < lines.length && !/^\s*```/.test(lines[index])) {
        codeLines.push(lines[index])
        index++
      }
      if (index < lines.length) index++

      const block = document.createElement('div')
      block.className = 'code-block'
      const head = document.createElement('div')
      head.className = 'code-block-head'
      const languageLabel = document.createElement('span')
      languageLabel.textContent = language
      const copy = document.createElement('button')
      copy.type = 'button'
      copy.className = 'copy-code-button'
      copy.textContent = 'Copy code'
      const codeText = codeLines.join('\n')
      copy.addEventListener('click', async () => {
        try {
          await window.glassAI.copyText(codeText)
          copy.textContent = 'Copied'
          setTimeout(() => { copy.textContent = 'Copy code' }, 1400)
        } catch {
          toast('Could not copy code to the clipboard.')
        }
      })
      head.append(languageLabel, copy)
      const pre = document.createElement('pre')
      const code = document.createElement('code')
      code.textContent = codeText
      pre.appendChild(code)
      block.append(head, pre)
      container.appendChild(block)
      continue
    }

    const heading = line.match(/^\s{0,3}(#{1,4})\s+(.+)$/)
    if (heading) {
      const node = document.createElement(`h${heading[1].length + 2}`)
      appendInlineMarkdown(node, heading[2])
      container.appendChild(node)
      index++
      continue
    }

    if (/^\s*[-*+]\s+/.test(line)) {
      const list = document.createElement('ul')
      while (index < lines.length && /^\s*[-*+]\s+/.test(lines[index])) {
        const item = document.createElement('li')
        appendInlineMarkdown(item, lines[index].replace(/^\s*[-*+]\s+/, ''))
        list.appendChild(item)
        index++
      }
      container.appendChild(list)
      continue
    }

    if (/^\s*\d+[.)]\s+/.test(line)) {
      const list = document.createElement('ol')
      while (index < lines.length && /^\s*\d+[.)]\s+/.test(lines[index])) {
        const item = document.createElement('li')
        appendInlineMarkdown(item, lines[index].replace(/^\s*\d+[.)]\s+/, ''))
        list.appendChild(item)
        index++
      }
      container.appendChild(list)
      continue
    }

    const paragraphLines = []
    while (index < lines.length && lines[index].trim() && !/^\s*```/.test(lines[index]) && !/^\s{0,3}#{1,4}\s+/.test(lines[index]) && !/^\s*[-*+]\s+/.test(lines[index]) && !/^\s*\d+[.)]\s+/.test(lines[index])) {
      paragraphLines.push(lines[index])
      index++
    }
    const paragraph = document.createElement('p')
    appendInlineMarkdown(paragraph, paragraphLines.join('\n'))
    container.appendChild(paragraph)
  }
}

let conversationMemory = []
let restoringConversation = false

function persistConversation() {
  if (!restoringConversation) window.glassAI.saveConversationMemory(conversationMemory).catch(() => {})
}

function addMessage(kind, text, image = null, label = null) {
  welcome.hidden = true
  const wrap = document.createElement('div')
  wrap.className = `message ${kind}`
  if (label === 'generated-image') wrap.classList.add('generated-image-message')
  const bubble = document.createElement('div')
  bubble.className = 'bubble'
  if (kind === 'assistant' && text) renderAssistantMarkdown(bubble, text)
  else if (text) bubble.textContent = text
  if (image) {
    const img = document.createElement('img')
    img.src = image
    img.alt = label === 'generated-image' ? 'AI-generated image' : 'Screen capture'
    if (label === 'generated-image') img.className = 'generated-image'
    bubble.appendChild(img)
  }
  wrap.appendChild(bubble)
  if (image && label === 'generated-image') {
    const actions = document.createElement('div')
    actions.className = 'generated-image-actions'
    const save = document.createElement('button')
    save.type = 'button'
    save.className = 'save-image-button'
    save.textContent = 'Save image'
    save.addEventListener('click', async () => {
      try {
        const result = await window.glassAI.saveImage(image)
        if (!result.canceled) toast('Image saved.')
      } catch (error) {
        toast(error.message || 'Could not save the image.')
      }
    })
    actions.appendChild(save)
    wrap.appendChild(actions)
  }
  conversation.appendChild(wrap)
  conversation.scrollTop = conversation.scrollHeight
  if (text && ['user', 'assistant'].includes(kind)) {
    conversationMemory.push({ role: kind, text: String(text), time: Date.now() })
    conversationMemory = conversationMemory.slice(-40)
    persistConversation()
  }
  return wrap
}

function addLoading(isImage = false) {
  const wrap = addMessage('assistant', isImage ? 'Creating your image…' : 'Thinking…')
  wrap.classList.add('loading')
  if (isImage) wrap.classList.add('image-loading')
  return wrap
}

function updateStatus(status) {
  const connected = Boolean(status?.connected)
  const sharing = Boolean(status?.sharing)
  $('connectionText').textContent = connected ? (sharing ? 'Connected' : 'Permission needed') : 'Not connected'
  $('connectionDot').classList.toggle('connected', connected && sharing)
  $('connectionDot').classList.toggle('warning', connected && !sharing)
  $('accountGlyph').textContent = connected ? '●' : '↗'
  $('accountButton').title = connected ? 'ChatGPT connected' : 'Connect ChatGPT'
  $('settingsAccount').textContent = connected ? `${status.account?.name || 'ChatGPT account'}${status.account?.email ? ` · ${status.account.email}` : ''}${sharing ? ' · ChatGPT plan enabled' : ' · AI permission not granted'}` : 'Not connected'
  $('connectButton').textContent = connected ? 'Reconnect with ChatGPT' : 'Continue with ChatGPT'
  $('disconnectButton').hidden = !connected
  if (connected && sharing) setStatus('Connected · Using ChatGPT plan')
  else if (connected) setStatus('Connected, but ChatGPT plan usage is not enabled')
  else setStatus('Ready')
}

async function refreshStatus() {
  try { updateStatus(await window.glassAI.getStatus()) } catch { updateStatus(null) }
}

async function refreshPrivacy() {
  try {
    const state = await window.glassAI.getPrivacy()
    $('privacyToggle').checked = Boolean(state.enabled)
    updatePrivacyNote(Boolean(state.enabled))
  } catch {
    $('privacyToggle').checked = false
    updatePrivacyNote(false)
  }
}

function updatePrivacyNote(enabled) {
  $('privacyNote').textContent = enabled
    ? 'On · Nebula AI - Lunar is protected from supported screen-capture methods.'
    : 'Off · The assistant may appear in screen recordings.'
}

function isImageRequest(prompt) {
  const text = String(prompt || '')
  return /\b(generate|create|draw|paint|illustrate|render|make|turn|convert)\b.{0,90}\b(image|picture|illustration|artwork|wallpaper|logo|icon|poster|thumbnail|graphic|visual)\b/i.test(text) ||
    /\b(make|turn|convert)\s+(this|that|it|the\s+svg)\s+(into|as)\s+(an?\s+)?(image|picture|png|jpg|jpeg)\b/i.test(text)
}

async function submitPrompt(textOverride = null) {
  if (busy) return
  const prompt = String(textOverride ?? promptInput.value).trim()
  if (!prompt && !imageData && attachedFiles.length === 0) {
    promptInput.focus()
    return
  }
  const generateImage = isImageRequest(prompt)
  showPanel()
  hideViews()
  const priorConversation = conversationMemory.slice(-16).map(item => ({ role: item.role, text: item.text }))
  const submittedImage = imageData
  const submittedFiles = attachedFiles.slice()
  const userText = prompt || 'Please analyze the attached material.'
  addMessage('user', userText, submittedImage)
  if (submittedFiles.length) addMessage('user', `Attached: ${submittedFiles.map(file => file.name).join(', ')}`)
  promptInput.value = ''
  imageData = null
  attachedFiles = []
  attachment.hidden = true
  busy = true
  $('sendButton').disabled = true
  setStatus(generateImage ? 'Creating your image…' : 'Sending your request…')
  const loading = addLoading(generateImage)
  activeLoading = loading
  try {
    let requestPrompt = prompt
    if (isScreenCaptureRequest) {
      showExplanation = Boolean($('showExplanationToggle')?.checked)
      const captureInstructions = showExplanation
        ? `You MUST provide BOTH sections below. Do not omit the explanation.\n\nANSWER:\nGive the exact final answer first. Keep this section short and suitable for the floating answer card.\n\nEXPLANATION:\nExplain what the question is asking in plain language, then show the steps used to solve it. Explain why the answer is correct. Include the relevant formula or rule and define important symbols. Use proper mathematical symbols and notation throughout the explanation, not plain-text slash codes. Use **bold** only for important terms or section labels. Do not put any explanation in the ANSWER section.`
        : `Provide ONLY the final answer. Do not include steps, reasoning, definitions, or an explanation.`
      requestPrompt = `${prompt}\n\nSCREEN CAPTURE RESPONSE SETTINGS:\n${captureInstructions}\n\nFormatting requirements: use readable standard mathematical notation. Use actual Unicode symbols or syntactically complete LaTeX commands only; never output broken fragments such as /ge, /geq, /le, /pi, or partial commands. Convert common notation to visible symbols where possible: ≥, ≤, ≠, ≈, ±, ×, ÷, ·, √, ∛, π, θ, α, β, γ, Δ, Σ, ∑, ∫, ∞, ∈, ∉, ∪, ∩, →, ↔, ⇒. Use correct superscripts, subscripts, fractions, and exponents. Apply the same notation quality to BOTH ANSWER and EXPLANATION. If the image is unclear, say what cannot be read rather than guessing.`
    }
    const result = await window.glassAI.ask({ prompt: requestPrompt, imageData: submittedImage, attachments: submittedFiles, generateImage, conversation: priorConversation })
    if (result.highlightBox && captureBounds) {
      const box = result.highlightBox
      const rawX = captureBounds.x + captureBounds.width * box.x / 1000
      const rawY = captureBounds.y + captureBounds.height * box.y / 1000
      const rawWidth = captureBounds.width * box.width / 1000
      const rawHeight = captureBounds.height * box.height / 1000
      const padX = Math.max(12, rawWidth * 0.18)
      const padY = Math.max(9, rawHeight * 0.28)
      const left = Math.max(captureBounds.x, rawX - padX)
      const top = Math.max(captureBounds.y, rawY - padY)
      const right = Math.min(captureBounds.x + captureBounds.width, rawX + rawWidth + padX)
      const bottom = Math.min(captureBounds.y + captureBounds.height, rawY + rawHeight + padY)
      await window.glassAI.showAnswerHighlight({
        x: left,
        y: top,
        width: right - left,
        height: bottom - top
      }).catch(() => {})
    }
    captureBounds = null
    loading.remove()
    activeLoading = null
    if (result.imageData) {
      addMessage('assistant', result.answer || '', result.imageData, 'generated-image')
      setStatus('Image ready · Save it to your PC')
    } else {
      if (isScreenCaptureRequest) {
        const parts = splitCaptureAnswer(result.answer)
        const answerText = parts.answer || result.answer
        await window.glassAI.showAnswerToast({ answer: answerText, duration: answerToastDuration }).catch(() => {})
        const chatText = showExplanation && parts.explanation && parts.explanation.toLowerCase() !== 'disabled'
          ? `**Answer**\n${answerText}\n\n**Explanation**\n${parts.explanation}`
          : `**Answer**\n${answerText}`
        addMessage('assistant', chatText)
      } else {
        addMessage('assistant', result.answer)
      }
      setStatus('Completed · Using ChatGPT plan')
    }
    isScreenCaptureRequest = false
  } catch (error) {
    isScreenCaptureRequest = false
    captureBounds = null
    loading.remove()
    activeLoading = null
    addMessage('assistant', error.message || 'Something went wrong. Please try again.')
    setStatus('Request failed')
  } finally {
    busy = false
    $('sendButton').disabled = false
    promptInput.focus()
  }
}

async function refreshImageApiKeyStatus() {
  try {
    const state = await window.glassAI.getImageApiKeyStatus()
    $('imageApiKeyStatus').textContent = state.configured
      ? 'An API key is saved securely. Image generation uses OpenAI API billing, separate from ChatGPT.'
      : 'No API key saved. ChatGPT sign-in alone cannot provide image generation for this app.'
  } catch {
    $('imageApiKeyStatus').textContent = 'Could not check the image API key status.'
  }
}

$('saveImageApiKeyButton').addEventListener('click', async () => {
  const input = $('imageApiKeyInput')
  const key = input.value.trim()
  if (!key) {
    toast('Paste your OpenAI API key first.')
    return
  }
  $('saveImageApiKeyButton').disabled = true
  try {
    await window.glassAI.saveImageApiKey(key)
    input.value = ''
    await refreshImageApiKeyStatus()
    toast('Image API key saved securely.')
  } catch (error) {
    toast(error.message || 'Could not save the API key.')
  } finally {
    $('saveImageApiKeyButton').disabled = false
  }
})

$('clearImageApiKeyButton').addEventListener('click', async () => {
  try {
    await window.glassAI.saveImageApiKey('')
    $('imageApiKeyInput').value = ''
    await refreshImageApiKeyStatus()
    toast('Image API key removed.')
  } catch (error) {
    toast(error.message || 'Could not remove the API key.')
  }
})

function showSettings() {
  showPanel()
  conversation.hidden = true
  historyView.hidden = true
  settingsView.hidden = false
  $('attachment').hidden = true
  refreshStatus()
  refreshPrivacy()
  refreshBlur()
  refreshImageApiKeyStatus()
}

async function showHistory() {
  showPanel()
  conversation.hidden = true
  settingsView.hidden = true
  historyView.hidden = false
  $('attachment').hidden = true
  const list = $('historyList')
  list.replaceChildren()
  const history = await window.glassAI.getHistory()
  if (!history.length) {
    const empty = document.createElement('div')
    empty.className = 'empty-history'
    empty.textContent = 'Your recent questions and answers will appear here.'
    list.appendChild(empty)
    return
  }
  history.slice().reverse().forEach(item => {
    const row = document.createElement('div')
    row.className = 'history-item'
    const copy = document.createElement('button')
    copy.type = 'button'
    copy.className = 'history-item-copy'
    const title = document.createElement('strong')
    title.textContent = item.prompt || 'Screen capture question'
    const meta = document.createElement('small')
    meta.textContent = `${new Date(item.time).toLocaleString()} · ${item.model}${item.hasImage ? ' · Screenshot used' : ''}`
    copy.append(title, meta)
    copy.addEventListener('click', () => {
      historyView.hidden = true
      settingsView.hidden = true
      conversation.hidden = false
      welcome.hidden = true
      conversation.querySelectorAll('.message').forEach(node => node.remove())
      addMessage('user', item.prompt || 'Screen capture question')
      addMessage('assistant', item.answer)
      showPanel()
    })
    const remove = document.createElement('button')
    remove.type = 'button'
    remove.className = 'history-delete-button'
    remove.textContent = 'Delete'
    remove.title = 'Delete this history item'
    remove.addEventListener('click', async event => {
      event.stopPropagation()
      await window.glassAI.deleteHistoryItem(item.id)
      toast('History item deleted.')
      showHistory()
    })
    row.append(copy, remove)
    list.appendChild(row)
  })
}

async function refreshBlur() {
  try {
    const state = await window.glassAI.getBlur()
    const value = Number(state.value) || 0
    $('blurSlider').value = value
    $('blurValue').textContent = `${value} px`
    document.documentElement.style.setProperty('--glass-blur', `${value}px`)
    document.documentElement.style.setProperty('--glass-tint', String(value === 0 ? 0.22 : 0.22 + (value / 60) * 0.32))
  } catch {}
}

let blurSaveTimer = null
function applyBlurValue(value) {
  const amount = Math.max(0, Math.min(60, Number(value) || 0))
  $('blurValue').textContent = `${amount} px`
  document.documentElement.style.setProperty('--glass-blur', `${amount}px`)
  document.documentElement.style.setProperty('--glass-tint', String(amount === 0 ? 0.22 : 0.22 + (amount / 60) * 0.32))
}
$('blurSlider').addEventListener('input', event => {
  const value = Number(event.target.value)
  applyBlurValue(value)
  clearTimeout(blurSaveTimer)
  blurSaveTimer = setTimeout(async () => {
    try { await window.glassAI.setBlur(value) } catch { toast('Could not save the blur setting.') }
  }, 120)
})
window.glassAI.onBlurUpdated(value => applyBlurValue(value))

function startFreshChat() {
  conversationMemory = []
  window.glassAI.clearConversationMemory().catch(() => {})
  conversation.querySelectorAll('.message').forEach(node => node.remove())
  welcome.hidden = false
  imageData = null
  attachment.hidden = true
  promptInput.value = ''
  hideViews()
  conversation.scrollTop = 0
  setStatus('New chat')
}

$('deleteAllHistoryButton').addEventListener('click', async () => {
  await window.glassAI.deleteAllHistory()
  startFreshChat()
  toast('All history deleted. You are in a fresh chat.')
})
$('newChatButton').addEventListener('click', () => {
  startFreshChat()
  toast('Started a fresh chat. Your saved history is unchanged.')
})

$('uploadButton').addEventListener('click', () => $('fileInput').click())

$('fileInput').addEventListener('change', async event => {
  const files = Array.from(event.target.files || [])
  const additions = []
  const maxSize = 12 * 1024 * 1024
  const textExt = /\.(txt|md|csv|json|js|ts|py|lua|html|css|xml|yaml|yml|log)$/i
  for (const file of files) {
    if (file.size > maxSize) { toast(`${file.name} is too large. Choose a file under 12 MB.`); continue }
    const type = file.type || (file.name.toLowerCase().endsWith('.pdf') ? 'application/pdf' : '')
    if (type.startsWith('image/') || type === 'application/pdf') {
      const data = await new Promise((resolve, reject) => {
        const reader = new FileReader()
        reader.onload = () => resolve(String(reader.result))
        reader.onerror = () => reject(new Error(`Could not read ${file.name}`))
        reader.readAsDataURL(file)
      })
      additions.push({ name: file.name, type, data })
    } else if (type.startsWith('text/') || ['application/json','application/javascript'].includes(type) || textExt.test(file.name)) {
      additions.push({ name: file.name, type: type || 'text/plain', data: 'data:text/plain;base64,' + btoa(unescape(encodeURIComponent(await file.text()))), text: await file.text() })
    } else {
      toast(`${file.name}: unsupported file type. Try an image, PDF, or text/code file.`)
    }
  }
  attachedFiles = attachedFiles.concat(additions)
  if (attachedFiles.length) {
    const image = attachedFiles.find(file => file.type.startsWith('image/'))
    attachmentPreview.hidden = !image
    if (image) attachmentPreview.src = image.data
    else attachmentPreview.removeAttribute('src')
    $('attachmentTitle').textContent = `${attachedFiles.length} attachment${attachedFiles.length === 1 ? '' : 's'} ready`
    $('attachmentSubtitle').textContent = attachedFiles.map(file => file.name).join(', ')
    attachment.hidden = false
    showPanel()
    setStatus('Attachments ready · Add a question or send to analyze')
  }
  event.target.value = ''
})

$('promptForm').addEventListener('submit', event => {
  event.preventDefault()
  submitPrompt()
})
promptInput.addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault()
    submitPrompt()
  }
})
promptInput.addEventListener('input', () => {
  promptInput.style.height = 'auto'
  promptInput.style.height = `${Math.min(promptInput.scrollHeight, 65)}px`
})
$('captureButton').addEventListener('click', () => window.glassAI.capture())
$('closeButton').addEventListener('click', () => window.glassAI.hide())
$('accountButton').addEventListener('click', showSettings)
loadAnswerDisplaySettings()
$('showExplanationToggle')?.addEventListener('change', event => {
  showExplanation = Boolean(event.target.checked)
  try { localStorage.setItem('nebulaShowExplanation', showExplanation ? 'true' : 'false') } catch {}
  toast(showExplanation
    ? 'Explanations enabled for the next screen capture.'
    : 'Answer-only mode enabled for the next screen capture.')
})
$('answerToastDuration')?.addEventListener('change', event => {
  answerToastDuration = Math.max(1, Math.min(60, Math.round(Number(event.target.value) || 5)))
  event.target.value = String(answerToastDuration)
  try { localStorage.setItem('nebulaAnswerToastDuration', String(answerToastDuration)) } catch {}
})
$('settingsButton').addEventListener('click', showSettings)
$('historyButton').addEventListener('click', showHistory)
$('backButton').addEventListener('click', () => { hideViews(); refreshStatus() })
$('historyBackButton').addEventListener('click', () => { hideViews(); refreshStatus() })
$('connectButton').addEventListener('click', async () => {
  $('connectButton').disabled = true
  $('connectButton').textContent = 'Opening secure sign-in…'
  try {
    const status = await window.glassAI.signIn()
    updateStatus(status)
    toast(status.sharing ? 'ChatGPT plan connected.' : 'Signed in. ChatGPT plan usage may not have been enabled.')
  } catch (error) {
    toast(error.message || 'Could not connect to ChatGPT.')
  } finally {
    $('connectButton').disabled = false
    refreshStatus()
  }
})
$('disconnectButton').addEventListener('click', async () => {
  const status = await window.glassAI.signOut()
  updateStatus(status)
  toast('ChatGPT account disconnected from this app.')
})
$('usageButton').addEventListener('click', () => window.glassAI.openUsage())
$('privacyToggle').addEventListener('change', async () => {
  const toggle = $('privacyToggle')
  toggle.disabled = true
  try {
    const result = await window.glassAI.setPrivacy(toggle.checked)
    toggle.checked = Boolean(result.enabled)
    updatePrivacyNote(Boolean(result.enabled))
    toast(result.enabled
      ? 'Screen-capture protection enabled where supported.'
      : 'Screen-capture protection disabled.')
  } catch (error) {
    toggle.checked = false
    updatePrivacyNote(false)
    toast(error.message || 'Could not update screen privacy.')
  } finally {
    toggle.disabled = false
  }
})


const dragSurfaces = [document.querySelector('.bar'), document.querySelector('.panel-head')].filter(Boolean)
let dragState = null
for (const surface of dragSurfaces) {
  surface.addEventListener('pointerdown', async event => {
    if (event.button !== 0 || event.target.closest('button, textarea, input, form, .head-actions, .prompt-form')) return
    event.preventDefault()
    if (dragState) return
    const pointerId = event.pointerId
    const startX = event.screenX
    const startY = event.screenY
    await window.glassAI.setWindowDragging(true)
    const bounds = await window.glassAI.getWindowBounds()
    if (!bounds || dragState) {
      await window.glassAI.setWindowDragging(false)
      return
    }
    dragState = { pointerId, startX, startY, x: bounds.x, y: bounds.y, surface }
    surface.setPointerCapture(pointerId)
    surface.classList.add('dragging')
  })
  surface.addEventListener('pointermove', event => {
    if (!dragState || event.pointerId !== dragState.pointerId) return
    window.glassAI.moveWindow({
      x: dragState.x + event.screenX - dragState.startX,
      y: dragState.y + event.screenY - dragState.startY
    })
  })
  const finishDrag = event => {
    if (!dragState || (event && event.pointerId !== dragState.pointerId)) return
    dragState.surface.classList.remove('dragging')
    dragState = null
    window.glassAI.setWindowDragging(false).catch(() => {})
  }
  surface.addEventListener('pointerup', finishDrag)
  surface.addEventListener('pointercancel', finishDrag)
  surface.addEventListener('lostpointercapture', finishDrag)
}

const resizeGrip = $('resizeGrip')
let resizeState = null
let resizeFrame = 0
resizeGrip.addEventListener('pointerdown', event => {
  if (!expanded || event.button !== 0) return
  event.preventDefault()
  event.stopPropagation()
  resizeState = {
    pointerId: event.pointerId,
    x: event.screenX,
    y: event.screenY,
    width: window.innerWidth,
    height: window.innerHeight
  }
  resizeGrip.setPointerCapture(event.pointerId)
})
resizeGrip.addEventListener('pointermove', event => {
  if (!resizeState || event.pointerId !== resizeState.pointerId) return
  const width = Math.max(560, Math.min(1600, resizeState.width + event.screenX - resizeState.x))
  const height = Math.max(360, Math.min(1200, resizeState.height + event.screenY - resizeState.y))
  if (resizeFrame) cancelAnimationFrame(resizeFrame)
  resizeFrame = requestAnimationFrame(() => window.glassAI.resizeWindow({ width, height }))
})
function finishResize(event) {
  if (!resizeState || (event && event.pointerId !== resizeState.pointerId)) return
  resizeState = null
  if (resizeFrame) cancelAnimationFrame(resizeFrame)
  resizeFrame = 0
}
resizeGrip.addEventListener('pointerup', finishResize)
resizeGrip.addEventListener('pointercancel', finishResize)
$('removeAttachment').addEventListener('click', () => {
  imageData = null
  attachedFiles = []
  attachment.hidden = true
  attachmentPreview.removeAttribute('src')
})
document.querySelectorAll('[data-prompt]').forEach(button => button.addEventListener('click', () => submitPrompt(button.dataset.prompt)))
window.glassAI.onGenerationProgress(progress => {
  if (!activeLoading) return
  const bubble = activeLoading.querySelector('.bubble')
  if (!bubble) return
  if (progress.type === 'status') {
    const preview = bubble.querySelector('.generation-preview')
    bubble.textContent = progress.text || 'Creating your image…'
    if (preview) bubble.appendChild(preview)
  }
  if (progress.type === 'partial-image' && progress.dataUrl) {
    let preview = bubble.querySelector('.generation-preview')
    if (!preview) {
      preview = document.createElement('img')
      preview.className = 'generation-preview'
      preview.alt = 'Image preview being generated'
      bubble.appendChild(preview)
    }
    preview.src = progress.dataUrl
  }
})

window.glassAI.onImageCaptured(capture => {
  isScreenCaptureRequest = true
  showExplanation = Boolean($('showExplanationToggle')?.checked)
  try { localStorage.setItem('nebulaShowExplanation', showExplanation ? 'true' : 'false') } catch {}
  imageData = capture.dataUrl
  captureBounds = capture.bounds || null
  attachmentPreview.src = capture.dataUrl
  attachment.hidden = false
  showPanel()
  hideViews()
  promptInput.value = 'Solve the question shown in this screenshot. Read every visible instruction and answer field carefully. Give the exact value to enter in each text or number box, and the exact visible option label to choose in each dropdown. List answers in the same order as the fields appear. Follow the answer/explanation setting selected in Settings. If a field or option is unreadable, say so instead of guessing.'
  submitPrompt()
})
window.glassAI.onStatusUpdated(updateStatus)
window.glassAI.onStatusMessage(setStatus)
window.glassAI.onOverlayOpened(() => { promptInput.focus() })
window.glassAI.onOverlayBlurred(() => {})

document.addEventListener('keydown', event => {
  const editable = event.target && (
    event.target.matches('input, textarea, select') ||
    event.target.isContentEditable
  )
  if (editable || event.ctrlKey || event.altKey || event.metaKey || event.repeat) return
  const configured = captureHotkeyInputValue
  if (configured && /^[A-Za-z0-9]$/.test(configured) && event.key.toUpperCase() === configured.toUpperCase()) {
    event.preventDefault()
    window.glassAI.captureHotkeyPressed().catch(() => {})
  }
})

let captureHotkeyInputValue = 'Alt+Shift+A'

const captureHotkeyInput = $('captureHotkeyInput')
const captureHotkeyButton = $('captureHotkeyButton')
const captureHotkeyEnabled = $('captureHotkeyEnabled')
if (captureHotkeyInput) {
  window.glassAI.getCaptureHotkey().then(value => {
    captureHotkeyInputValue = value.accelerator
    captureHotkeyInput.value = value.accelerator.replaceAll('+', ' + ')
    if (captureHotkeyEnabled) captureHotkeyEnabled.checked = value.enabled !== false
  }).catch(() => {})
  if (captureHotkeyButton) captureHotkeyButton.addEventListener('click', () => {
    captureHotkeyInput.focus()
    toast('Press any key or key combination. Examples: T, Ctrl + T, or F8. Press Escape to cancel.')
  })
  captureHotkeyInput.addEventListener('keydown', async event => {
    event.preventDefault()
    if (event.key === 'Escape') { captureHotkeyInput.blur(); toast('Hotkey selection cancelled.'); return }
    if (['Control', 'Shift', 'Alt', 'Meta'].includes(event.key)) return
    const parts = []
    if (event.ctrlKey) parts.push('Ctrl')
    if (event.altKey) parts.push('Alt')
    if (event.shiftKey) parts.push('Shift')
    if (event.metaKey) parts.push('Super')
    const keyMap = { ' ': 'Space', 'ArrowUp': 'Up', 'ArrowDown': 'Down', 'ArrowLeft': 'Left', 'ArrowRight': 'Right' }
    const key = keyMap[event.key] || (event.key.length === 1 ? event.key.toUpperCase() : event.key)
    if (['Tab', 'Enter', 'Escape'].includes(key)) { toast('Choose another key.'); return }
    parts.push(key)
    try {
      const result = await window.glassAI.setCaptureHotkey(parts.join('+'))
      captureHotkeyInput.value = result.accelerator.replaceAll('+', ' + ')
      toast('Screen capture hotkey saved.')
    } catch (error) { toast(error.message || 'Could not save hotkey.') }
  })
  if (captureHotkeyEnabled) captureHotkeyEnabled.addEventListener('change', async () => {
    try {
      const result = await window.glassAI.setCaptureHotkeyEnabled(captureHotkeyEnabled.checked)
      captureHotkeyEnabled.checked = result.enabled
      toast(result.enabled ? 'Capture hotkey enabled.' : 'Capture hotkey disabled.')
    } catch (error) {
      captureHotkeyEnabled.checked = !captureHotkeyEnabled.checked
      toast(error.message || 'Could not change hotkey setting.')
    }
  })
}

window.addEventListener('keydown', event => {
  if (event.key === 'Escape') window.glassAI.hide()
})
async function restoreConversationMemory() {
  try {
    const saved = await window.glassAI.loadConversationMemory()
    if (!Array.isArray(saved) || !saved.length) return
    restoringConversation = true
    conversationMemory = saved.slice(-40)
    for (const item of conversationMemory) {
      if (item && ['user', 'assistant'].includes(item.role) && typeof item.text === 'string') {
        addMessage(item.role, item.text)
      }
    }
  } catch {
    conversationMemory = []
  } finally {
    restoringConversation = false
  }
}

restoreConversationMemory()
refreshStatus()
refreshPrivacy()

const { contextBridge, ipcRenderer } = require('electron')
contextBridge.exposeInMainWorld('answerToast', {
  onAnswer: callback => ipcRenderer.on('answer-toast-content', (_, value) => callback(value)),
  reportSize: size => ipcRenderer.send('answer-toast-size', size)
})

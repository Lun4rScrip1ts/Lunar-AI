function normalizeMathText(value) {
  return String(value || '')
    .replace(/\\(?:geq?|ge)(?![A-Za-z])/g, '≥')
    .replace(/\\(?:leq?|le)(?![A-Za-z])/g, '≤')
    .replace(/\\neq(?![A-Za-z])/g, '≠')
    .replace(/\\approx(?![A-Za-z])/g, '≈')
    .replace(/\\times(?![A-Za-z])/g, '×')
    .replace(/\\cdot(?![A-Za-z])/g, '·')
    .replace(/\\div(?![A-Za-z])/g, '÷')
    .replace(/\\pm(?![A-Za-z])/g, '±')
    .replace(/\\pi(?![A-Za-z])/g, 'π')
    .replace(/\\theta(?![A-Za-z])/g, 'θ')
    .replace(/\\alpha(?![A-Za-z])/g, 'α')
    .replace(/\\beta(?![A-Za-z])/g, 'β')
    .replace(/\\gamma(?![A-Za-z])/g, 'γ')
    .replace(/\\Delta(?![A-Za-z])/g, 'Δ')
    .replace(/\\infty(?![A-Za-z])/g, '∞')
    .replace(/\\sqrt\s*\{([^{}]+)\}/g, '√($1)')
    .replace(/\\frac\s*\{([^{}]+)\}\s*\{([^{}]+)\}/g, '($1)/($2)')
    .replace(/\\left|\\right/g, '')
    .replace(/(^|[^A-Za-z])\/(?:geq?|leq?|neq|approx|times|div|pm|pi|theta|alpha|beta|gamma)(?=$|[^A-Za-z])/g, (_, prefix, cmd) => {
      const symbols = { ge: '≥', geq: '≥', le: '≤', leq: '≤', neq: '≠', approx: '≈', times: '×', div: '÷', pm: '±', pi: 'π', theta: 'θ', alpha: 'α', beta: 'β', gamma: 'γ' }
      return prefix + (symbols[cmd] || '')
    })
    .replace(/\\{1,2}([()[\]])/g, '$1')
    .replace(/\r\n?/g, '\n')
}

function appendSafeMarkdown(parent, value) {
  const text = normalizeMathText(value)
  const pattern = /(\*\*[^*\n]+?\*\*|__[^_\n]+?__|\*[^*\n]+?\*|_[^_\n]+?_|`[^`\n]+`)/g
  let last = 0
  let match
  while ((match = pattern.exec(text))) {
    if (match.index > last) parent.appendChild(document.createTextNode(text.slice(last, match.index)))
    const token = match[0]
    const strong = token.startsWith('**') || token.startsWith('__')
    const italic = !strong && (token.startsWith('*') || token.startsWith('_'))
    const node = document.createElement(strong ? 'strong' : italic ? 'em' : 'code')
    node.textContent = token.slice(strong ? 2 : 1, strong ? -2 : -1)
    parent.appendChild(node)
    last = pattern.lastIndex
  }
  if (last < text.length) parent.appendChild(document.createTextNode(text.slice(last)))
}

function reportCardSize() {
  const card = document.querySelector('.card')
  const answer = document.getElementById('answer')
  if (!card || !answer) return
  const height = Math.ceil(card.scrollHeight + 2)
  window.answerToast.reportSize({ height })
}

window.answerToast.onAnswer(value => {
  const answer = document.getElementById('answer')
  answer.replaceChildren()
  String(value || '').split('\n').forEach((line, index) => {
    if (index) answer.appendChild(document.createElement('br'))
    appendSafeMarkdown(answer, line)
  })
  requestAnimationFrame(() => {
    reportCardSize()
    setTimeout(reportCardSize, 80)
  })
})
new ResizeObserver(reportCardSize).observe(document.getElementById('answer'))
window.addEventListener('load', reportCardSize)
